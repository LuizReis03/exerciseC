#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	
	float x = 0.0;
	float b = 0.0;
	float a = 0.0;
	
	printf("Digite o valor do coeficiente A: ");
	scanf("%f", &a);
	printf("Digite o valor do coeficiente B: ");
	scanf("%f", &b);
	
	x = (-b / a);
	printf("O valor de X e = %.2f", x);
	
	return 0;
}
