#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	
	float a = 0.0;
	float b = 0.0;
	float c = 0.0;
	float delta = 0.0;
	float x1 = 0.0;
	float x2 = 0.0;
	
	printf("Digite o valor do coeficiente A: ");
	scanf("%f", &a);
	printf("Digite o valor do coeficiente B: ");
	scanf("%f", &b);
	printf("Digite o valor do coeficiente C: ");
	scanf("%f", &c);
	
	delta = pow(b,2) - (4*a*c);
	
	printf("\nDelta: %.2f \n\n", delta);
	if(delta > 0) {
		
		x1 = (-b - sqrt(delta)) / (2*a);
		x2 = (-b + sqrt(delta)) / (2*a);
		printf("X1 = %.2f \nX2 = %.2f", x1,x2);
	
	}else if(delta == 0){
		
		x1 = (-b / (2*a));
		printf("X1 = %2.f", x1);
		
	}else if (delta < 0){
		
		printf("Nao existe a raiz");
		
	}

return 0;
}
