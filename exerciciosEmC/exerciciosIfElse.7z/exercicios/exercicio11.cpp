#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int a = 0;
	int b = 0;
	int c = 0;
	int soma = 0;
	
	printf("Digite o primeiro numero: ");
	scanf("%i", &a);
	
	printf("Digite o segundo numero: ");
	scanf("%i", &b);
	
	printf("Digite o segundo numero: ");
	scanf("%i", &c);
	
	soma = a + b + c;
	
	if (soma >= 100){
		printf("Resultado: %i", soma);
	}
	
	
return 0;
}
