#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int num1 = 0;
	int num2 = 0;
	int num3 = 0;
	int num4 = 0;
	
	printf("Digite o primeiro numero: ");
	scanf("%i", &num1);
	printf("Digite o segundo numero: ");
	scanf("%i", &num2);
	printf("Digite o terceiro numero: ");
	scanf("%i", &num3);
	printf("Digite o quarto numero: ");
	scanf("%i", &num4);
	
	if(num1 % 2 == 0 || num1 % 3 == 0) {
		printf("O numero %d", num1);
		printf(" e divisivel por 2 ou 3\n\n");
	}
	
	if(num2 % 2 == 0 || num2 % 3 == 0) {
		printf("O numero %d", num2);
		printf(" e divisivel por 2 ou 3\n\n");
	}
	
	if(num3 % 2 == 0 || num3 % 3 == 0) {
		printf("O numero %d", num3);
		printf(" e divisivel por 2 ou 3\n\n");
	}
	
	if(num4 % 2 == 0 || num4 % 3 == 0) {
		printf("O numero %d", num4);
		printf(" e divisivel por 2 ou 3\n\n");
	}

return 0;	
}
