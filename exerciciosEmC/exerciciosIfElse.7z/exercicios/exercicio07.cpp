#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int num = 0;
	
	printf("Digite um numero: ");
	scanf("%i", &num);
	
	if(num % 2 == 0) {
		printf("%i", num);
		printf(" e par");
	}else{
		printf("%i", num);
		printf(" e impar");
	}
	
return 0;
}
