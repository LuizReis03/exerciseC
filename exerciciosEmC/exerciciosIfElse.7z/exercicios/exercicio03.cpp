#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int a = 2;
	int b = 6;
	int c = 8;
	int maior = 0;
	int meio = 0;
	int menor = 0;
	
	if(a > b && a > c){
		maior = a;
	}else if(b > a && b > c) {
			maior = b;
	}else if(c > a && c > b) {
		maior = c;
	}
	
	if(a < b && a < c){
		menor = a;
	}else if(b < a && b < c) {
		menor = b;
	}else if(c < a && c < b) {
		menor = c;
	}
	
	if(a < b && a > c){
		meio = a;
	}else if(b > a && b < c) {
		meio = b;
	}else if(c > a && c < b) {
		meio = c;
	}
	
	printf("Ordem crescente:\n");
	printf("%i\n", menor);
	printf("%i\n", meio);
	printf("%i\n", maior);
	
return 0;	
}
