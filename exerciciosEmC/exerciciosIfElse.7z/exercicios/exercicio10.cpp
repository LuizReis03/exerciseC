#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	char nome[255];
	char sexo;
	
	printf("Digite um nome: ");
	scanf("%s", &nome);
	
	printf("Digite o sexo dessa pessoa: ");
	scanf(" %c", &sexo);
	
	if(sexo == 'F' || sexo == 'f') {
		printf("Bem-vinda Sra");
		printf("%s", &nome);
	}else if(sexo == 'M' || sexo == 'm') {
		printf("Bem-vindo Sr");
		printf("%s", &nome);
	}else{
		printf("Sexo nao existe!!");
	}
	
	
return 0;
}
