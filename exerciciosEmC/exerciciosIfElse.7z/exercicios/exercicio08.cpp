#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int num = 0;
	
	printf("Digite um numero: ");
	scanf("%i", &num);
	
	if(num >= 1 && num <=9) {
		printf("%i", num);
		printf(" esta na faixa permitida");
	}else{
		printf("%i", num);
		printf(" nao esta na faixa permitida");
	}
	
return 0;
}
