#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int num = 0;
	
	printf("Digite um numero: ");
	scanf("%i", &num);
	
	if(!(num > 3)) {
		printf("%i", num);
		printf(" e menor que 3");
	}
	
return 0;
}
