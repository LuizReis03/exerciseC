#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {

	int a = 2;
	int b = 6;
	int c = 8;
	int d = 10;
	int maior = 0;
	int meioMaior = 0;
	int meioMenor = 0;
	int menor = 0;
	
	if(a > b && a > c && a > d){
		maior = a;
	}else if(b > a && b > c && b > d) {
			maior = b;
	}else if(c > a && c > b && c > d) {
		maior = c;
	}else if(d > a && d > b && d > c){
		maior = d;
	}
	
	if(a < b && a < c && a < d){
		menor = a;
	}else if(b < a && b < c && b < d) {
		menor = b;
	}else if(c < a && c < b && c < d) {
		menor = c;
	}else if(d < a && d < c && d < b){
		menor = d;
	}
	
	if(a > b && a < c && a < d){
		meioMenor = a;
	}else if(b > a && b < c && b < d) {
		meioMenor = b;
	}else if(c > a && c < b && c < d) {
		meioMenor = c;
	}else if(d > a && d < b && d < c){
		meioMenor = d;
	}
	
	
	if(a > b && a > c && a < d){
		meioMaior = a;
	}else if(b > a && b > c && b < d) {
		meioMaior = b;
	}else if(c > a && c > b && c < d) {
		meioMaior = c;
	}else if(d > a && d > b && d < c){
		meioMaior = d;
	}
		
	printf("Ordem crescente:\n");
	printf("%i\n", menor);
	printf("%i\n", meioMenor);
	printf("%i\n", meioMaior);
	printf("%i\n", maior);
	
return 0;	
}
