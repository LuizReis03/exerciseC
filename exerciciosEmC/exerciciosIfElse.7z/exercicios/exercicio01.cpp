#include <stdio.h>
#include <stdlib.h>

int main() {
	
	float nota1 = 0.0;
	float nota2 = 0.0;
	float nota3 = 0.0;
	float nota4 = 0.0;
	float notaRec = 0.0;
	float media1 = 0.0;
	float media2 = 0.0;
	
	printf("Digite a primeira nota: ");
	scanf("%f", &nota1);
	printf("Digite a segunda nota: ");
	scanf("%f", &nota2);
	printf("Digite a terceira nota: ");
	scanf("%f", &nota3);
	printf("Digite a quarta nota: ");
	scanf("%f", &nota4);
	
	media1 = (nota1 + nota2 + nota3 + nota4) / 4;
	
	if(media1 < 0.0 || media1 > 100.0) {
		printf("Algumas das notas est�o erradas!!");
	}
	if(media1 >= 70.0) {
		printf("Aluno aprovado!!\n");
		printf("Media: %.2f", media1);
	}else {
		printf("\n\nDigite a nota de recuperacao: ");
		scanf("%f", &notaRec);
		media2 = (media1 + notaRec) / 2;
	
		if (media2 <= 5.0) {
			printf("Aluno reprovado!!\n");
			printf("Media: %.2f", media2);
		}else{
			printf("Aluno aprovado!!\n");
			printf("Media: %.2f", media2);
		}
		
	}
	
	
	return 0;
}
