#include <stdio.h>
#include <stdlib.h>

main() {
	
	int i=0;
	
	for(i = 0;i < 10; i++){
		printf("%i\n", i);
	}
	
	i = 0;
	
	printf("\n\nComeca while");
	
	while(i < 10){
		printf("%i\n", i);
		i++;
	}
	
	printf("\n\nComeca DO while");
	i = 0;
	
	do{
		printf("%i\n", i);
		i++;
	}while(i < 10);
	
	return 0;
}


