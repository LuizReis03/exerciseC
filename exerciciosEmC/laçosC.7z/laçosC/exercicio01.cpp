#include <stdio.h>
#include <stdlib.h>

int main() {
	
	int a, b, i, j;
	
	printf("Digite um valor para A: ");
	scanf("%i", &a);
	
	do{
		for(int i = 1; i <= a; i++){
			j = i;
			while(j <= a){
				printf("%i\n", j);
				j ++;
			}
		}
		b = a;
		printf("Digite um novo valor para A: ");
		scanf("%i", &a);
		
	}while((a != b) && (a > 0));
	
	
	return 0;
}
