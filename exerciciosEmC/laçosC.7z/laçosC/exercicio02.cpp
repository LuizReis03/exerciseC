#include <stdio.h>
#include <stdlib.h>

int main() {
	
	int a, raiz, i;
	
	printf("Digite o valor para achar a raiz: ");
	scanf("%i", &a);
	
	i = 0;
	
	while(1){
		i++;
		if((i*i) >= a){
			break;
		}
	}
	
	printf("Raiz: %i", i);
	
	return 0;
}
