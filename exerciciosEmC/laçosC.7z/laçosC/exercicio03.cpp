#include <stdio.h>
#include <stdlib.h>

int main() {
int num, i, resultado = 0;

printf("Digite um valor para verificar se e primo: ");
scanf("%d", &num);

for (i = 2; i <= num /2; i++) {
	
	if(num % 2 == 0){
		resultado++;
		break;
	}
	}
	
	if(resultado == 0){
		printf("Numero %d e primo!!", num);
	}else{
		printf("Numero %d nao e primo!!", num);
	}
	
	return 0;
}
